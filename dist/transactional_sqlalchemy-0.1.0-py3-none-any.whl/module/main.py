import functools
import logging
from enum import Enum
from typing import Awaitable, Callable

from module.config import scoped_session_manager, transaction_context

AsyncCallable = Callable[..., Awaitable]


class Propagation(Enum):
    REQUIRED = "REQUIRED"
    REQUIRES_NEW = "REQUIRES_NEW"
    NESTED = "NESTED"


async def _do_fn_with_tx(func, session, *args, **kwargs):
    async with session.begin() as tx:
        transaction_context.set(session)
        try:
            result = await func(*args, **kwargs)
            await tx.commit()
            return result
        except:
            logging.exception("Transaction Error")
            await tx.rollback()
        finally:
            await session.close()
            transaction_context.set(None)


def transactional(
    _func: AsyncCallable | None = None,
    *,
    propagation: Propagation = Propagation.REQUIRED,
):
    def decorator(func: AsyncCallable):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            current_session = transaction_context.get()

            if current_session is None:
                current_session = scoped_session_manager.get_new_session()

            if propagation == Propagation.REQUIRED:
                if current_session:
                    # 이미 트랜잭션을 사용중인 경우 해당 트랜잭션을 사용
                    return await _do_fn_with_tx(func, current_session, *args, **kwargs)

                else:
                    # 사용 중인 트랜잭션이 없는경우, 새로운 트랜잭션 사용
                    new_session = scoped_session_manager.get_new_session()
                    return await _do_fn_with_tx(func, new_session, *args, **kwargs)

            elif propagation == Propagation.REQUIRES_NEW:
                new_session = scoped_session_manager.get_new_session(True)

                result = await _do_fn_with_tx(func, new_session, *args, **kwargs)

                # 기존 세션으로 복구
                transaction_context.set(current_session)
                return result

            elif propagation == Propagation.NESTED:
                if current_session.in_transaction():
                    # 사용중인 세션이 있다면 해당 세션을 사용
                    async with current_session.begin_nested() as save_point:
                        try:
                            result = await func(*args, **kwargs)
                            await save_point.commit()
                            return result
                        except Exception as e:
                            # 오류 발생 시, save point만 롤백
                            await save_point.rollback()
                            raise

        return wrapper

    if _func is None:
        return decorator
    else:
        return decorator(_func)
