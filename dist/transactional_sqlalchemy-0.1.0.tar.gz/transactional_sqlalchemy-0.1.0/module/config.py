from contextvars import ContextVar
from typing import Optional, Union
from sqlalchemy.ext.asyncio import (
    async_scoped_session,
    AsyncSession,
)
from sqlalchemy.orm import scoped_session, Session


def verify_config(**kwargs):
    """

    Args:
        **kwargs ():

    Returns:

    """
    if "scoped_session" not in kwargs:
        raise ValueError("scoped_session is required")


transaction_context: ContextVar[Optional[Session]] = ContextVar(
    "transaction_context", default=None
)


class ScopeAndSessionManager:
    __instance = None

    def __new__(cls, *args, **kwargs):
        if cls.__instance is None:
            cls.__instance = super(ScopeAndSessionManager, cls).__new__(cls)
        return cls.__instance

    def __init__(self, scoped_session_: Union[async_scoped_session, scoped_session]):
        """

        Args:
            scoped_session_ ():
        """
        verify_config(**{"scoped_session": scoped_session_})
        self.scoped_session_ = scoped_session_

    def get_new_session(self, force: bool = False) -> Union[Session, AsyncSession]:
        if force:
            return self.scoped_session_()
        else:
            return self.scoped_session_.session_factory()


global scoped_session_manager


def init_manager(
    session: Union[async_scoped_session, scoped_session],
) -> None:
    global scoped_session_manager
    scoped_session_manager = ScopeAndSessionManager(scoped_session_=session)
