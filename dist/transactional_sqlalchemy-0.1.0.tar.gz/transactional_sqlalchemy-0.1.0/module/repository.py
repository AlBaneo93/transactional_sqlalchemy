from abc import ABC

from module.main import transactional


class ITransactionalRepository(ABC):
    """
    Repository 클래스에서 상속받으면 자동으로 transactional 데코레이터를 적용하는 추상클래스
    """

    @classmethod
    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(kwargs)

        # 서브클래스에서 정의된 메서드들에 데코레이터를 자동으로 적용
        for attr_name, attr_value in cls.__dict__.items():
            if callable(attr_value) and not attr_name.startswith("__"):
                # 데코레이터를 자동으로 적용
                setattr(cls, attr_name, transactional(attr_value))
